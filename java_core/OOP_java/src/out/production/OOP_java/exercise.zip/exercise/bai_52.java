package exercise;

public class bai_52 {

}
