package exercise;

public class bai51_chinh_la_bai_50 {
    public static void main(String[] args) {
        System.out.println("Bai 51 la bai 50 :v ");
        System.out.println("Bai 50 neu viet ham size hay gi ra thi lau qua, nen em lam luon kieu bai 51 , thay co thong cam a");
    }
}
